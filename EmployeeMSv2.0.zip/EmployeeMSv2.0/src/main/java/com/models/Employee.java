package com.models;

import java.util.List;

public class Employee {
	//member variables
	private int eid;
	private String ename;
	private List skillset;
	
	public Employee() {
		super();
	}

	//setters and getters
	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}
	

	public List getSkillset() {
		return skillset;
	}

	public void setSkillset(List skillset) {
		this.skillset = skillset;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}
	
	public String toString() {
		
		return this.eid+","+this.ename+","+this.skillset;
	}
}
