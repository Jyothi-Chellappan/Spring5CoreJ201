package com.applicationtest;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.configuration.EmployeeConfiguration;

public class EmployeeApplicationTest {
	public static void main(String args[]) {
		AnnotationConfigApplicationContext ac = new AnnotationConfigApplicationContext(EmployeeConfiguration.class);
		ac.close();

}
}
