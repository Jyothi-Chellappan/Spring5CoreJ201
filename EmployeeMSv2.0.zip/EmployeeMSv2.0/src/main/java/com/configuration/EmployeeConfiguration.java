package com.configuration;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.models.Employee;

@Configuration
public class EmployeeConfiguration {

@Bean

public Employee returnEmployee() {
	
	Employee e1 = new Employee();
	e1.setEid(100);
	e1.setEname("abc");
	List<String> l = new ArrayList<String>();
	l.add("java");l.add("spring");
	e1.setSkillset(l);
	return e1;
}

}
