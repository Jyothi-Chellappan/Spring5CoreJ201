package com.main;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.config.Customer_Config;
import com.dao.Cust_DAO_Impl;
import com.model.Customer;
 
	public class Cust_db_Appn {
	 
	    public static void main(String args[]) {
	 
	        AbstractApplicationContext context = new AnnotationConfigApplicationContext(Customer_Config.class);
	        Cust_DAO_Impl Customerdao = (Cust_DAO_Impl) context.getBean(Cust_DAO_Impl.class);
	 
	        Customer c1 = new Customer(10, "abcd123", "abcd122", 32);
	        Customer c2 = new Customer(20, "mnr21", "mnr232", 25);
	        Customer c3 = new Customer(30, "sri1", "sri1", 40);
	 
	        Customerdao.addCustomer(c1);
	        Customerdao.addCustomer(c2);
	        Customerdao.addCustomer(c3);
	      
	        //witout maprow
	        List<Customer> l=Customerdao.findAllCustomers();
	        l.forEach(x->x.toString());
	                context.close();
	                
	                       
	                
	    }
	 
	}
