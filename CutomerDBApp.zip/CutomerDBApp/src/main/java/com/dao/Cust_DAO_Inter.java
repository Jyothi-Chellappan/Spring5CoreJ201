package com.dao;

import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;

import com.model.Customer;

public interface Cust_DAO_Inter {
		 
	    //userdefined methods to interact with database
		public void addCustomer(Customer customer);
		public Customer findCustomer(int CustomerId) ;
			///userdefined methods to select records from database
		 public List < Customer > findAllCustomers();

	 /*   public void editCustomer(Customer customer, int customerId);
	 	    public void deleteCustomer(int customerId);
	 	    public Customer find(int customerId);
	 	    public List < Customer > findAll();*/
	}