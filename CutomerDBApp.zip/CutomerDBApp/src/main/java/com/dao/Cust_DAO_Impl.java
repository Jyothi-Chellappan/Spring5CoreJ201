package com.dao;

	import java.util.List;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
//import org.springframework.jdbc.core.BeanPropertyRowMapper;
	import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;
import com.main.ResultSet;
import com.main.RowMapper;
import com.main.SQLException;
import com.model.Customer;
	 
	@Repository
	@Qualifier("personDao")
	public class Cust_DAO_Impl implements Cust_DAO_Inter {
		 
	    @Autowired
	    JdbcTemplate jdbcTemplate;
	 
	    public void addCustomer(Customer customer) {
	    	//jdbctemplate.update("query",getter method used to insert values);
	    	jdbcTemplate.update("INSERT INTO Customer "
	    			+ "(Customer_id, first_name, Last_name, age) "
	    			+ "VALUES (?, ?, ?, ?)",
	       customer.getCustomerid(),customer.getCustomerfirstname(),customer.getCustomerlastname(),customer.getAge());
	        System.out.println("Customer Added!!");
	    }
	    
	    public Customer findCustomer(int CustomerId) {
	        Customer Customer = (Customer) jdbcTemplate.queryForObject("SELECT * FROM Customer where Customer_id = ? ",
	            new Object[] { CustomerId }, new BeanPropertyRowMapper(Customer.class));
	 	        return Customer;
	    }

	    ///Query to read all records of a customer
	        
	      public List < Customer > findAllCustomers()   {
		       /* List < Customer > Customers = jdbcTemplate.query("SELECT * FROM Customer", new BeanPropertyRowMapper(Customer.class));
		        return Customers;*/
		        			//with maprow
	    	  String sql = "SELECT * FROM Customer";
	    	  
	    	 jdbcTemplate.queryForObject(sql, new Object[] {
						user.getUserId(), user.getPassword() }, String.class);
						
	    	  
			/* List<Customer> result = jdbcTemplate.query(sql, new RowMapper() {
			                	 
			                public Object mapRow(ResultSetExtractor rs, int rowNum) throws java.sql.SQLException {
			                    
			                        Customer contact = new Customer();
			                        Customer.setId(rs.getInt("contact_id"));
			                        Customer.setName(rs.getString("name"));
			                        Customer.setEmail(rs.getString("email"));
			                        Customer.setAddress(rs.getString("address"));
			               			               return Customer;
			                    }
			                }); */
			               
	        }
		
	    }//end of application
		
