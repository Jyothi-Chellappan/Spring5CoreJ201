package com.model;
import com.dao.Cust_DAO_Impl;
public class Customer {
  //member variables
  int customerid;
  String customerfirstname;
  String customerlastname;
  int age;
  Cust_DAO_Impl cust_dao_impl;
  
  public Customer() {
	  
  }
  public Customer(int customerid, String customerfirstname, String customerlastname, int age) {
	super();
	this.customerid = customerid;
	this.customerfirstname = customerfirstname;
	this.customerlastname = customerlastname;
	this.age = age;
}
  
public int getCustomerid() {
	return customerid;
}
public void setCustomerid(int customerid) {
	this.customerid = customerid;
}
public String getCustomerfirstname() {
	return customerfirstname;
}
public void setCustomerfirstname(String customerfirstname) {
	this.customerfirstname = customerfirstname;
}
public String getCustomerlastname() {
	return customerlastname;
}
public void setCustomerlastname(String customerlastname) {
	this.customerlastname = customerlastname;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public Cust_DAO_Impl getCust_dao_impl() {
	return cust_dao_impl;
}
public void setCust_dao_impl(Cust_DAO_Impl cust_dao_impl) {
	this.cust_dao_impl = cust_dao_impl;
}
	
 }
