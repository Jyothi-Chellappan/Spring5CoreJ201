package com.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.dao.Cust_DAO_Impl;
import com.model.Customer;

@Configuration
@Import(DB_Config.class)
public class Customer_Config {

	@Bean
	public Customer createCustomer(){
			return new Customer();
	}
	
	@Bean
	public Cust_DAO_Impl createCustomerDao() {
		return new Cust_DAO_Impl();
	}
}
