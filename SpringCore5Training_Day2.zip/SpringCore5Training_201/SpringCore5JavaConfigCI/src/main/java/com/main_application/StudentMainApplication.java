package com.main_application;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.config.StudentConfiguration;
import com.model.Course;
import com.model.Student;

public class StudentMainApplication {

	public static void main(String[] args) {

		AnnotationConfigApplicationContext ac= new AnnotationConfigApplicationContext(StudentConfiguration.class);
		Course c1=(com.model.Course)ac.getBean(Course.class);
		System.out.println(c1.toString());
		Student s1= (com.model.Student)ac.getBean(Student.class);
		System.out.println(s1);
	}

}
