package com.model;

import org.springframework.beans.factory.annotation.Autowired;

public class Student {
	
	private int sid;
	private String sname;
	private Course course1;
	
	public Student() {
		
	}
	@Autowired
	public Student(int id,String name,Course c1){
		this.sid=id;
		this.sname=name;
		this.course1=c1;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public Course getCourse1() {
		return course1;
	}

	public void setCourse1(Course course1) {
		this.course1 = course1;
	}
	
	public String toString() {
		
		return this.sid+","+this.sname+","+this.course1;
	}
}