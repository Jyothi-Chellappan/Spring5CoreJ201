package com.config;
/*
 * Program to demontrate constructor injection
 */
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.model.Course;
import com.model.Student;

	@Configuration
	@ComponentScan("com.model")
	public class StudentConfiguration {
	
	
	@Bean
	public Course createCourse() {
			return new Course();
	}
	
	@Bean
	public Student createStudent() {
		
		return new Student();
	}
	
		
	}