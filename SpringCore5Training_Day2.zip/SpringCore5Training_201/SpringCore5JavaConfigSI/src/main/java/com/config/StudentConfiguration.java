package com.config;
/*
 * Program to demontrate setter injection
 */
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.model.Course;
import com.model.Student;

	@Configuration
	@ComponentScan("com.model")
	public class StudentConfiguration {

	Course c1;
	Student s1;
	
	StudentConfiguration(){
		this.c1= new Course();
		this.s1=new Student();
	}
	@Bean
	public Course createCourse() {
		c1.setCourseid(100);
		c1.setCoursename("java");
		return new Course(c1.getCourseid(),c1.getCoursename());
	}
	   
	@Bean
	public Student createStudent() {
		s1.setCourse1(c1);
		s1.setSid(100);
		s1.setSname("AdvancedJava");
		return new Student(s1.getSid(),s1.getSname(),s1.getCourse1());
	}
	
	@Bean
	public Student createStudent(int i,String name) {
		c1.setCourseid(i);c1.setCoursename("java");
		return new Student(2000,"Sudent1",c1);
	}
	
	}