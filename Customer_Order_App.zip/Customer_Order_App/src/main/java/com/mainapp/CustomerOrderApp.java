package com.mainapp;
import java.util.Scanner;
/*Program to generate a Customer Order
 * Use @Scope,@Qualifier,@import,@PropertiesSource
 */
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.config.Cust_Ord_Config;
import com.models.Address;
import com.models.Order;
import com.models.Customer;
public class CustomerOrderApp {
public static void main(String args[]) {
	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(Cust_Ord_Config.class);
	//Explicit Typecasting is not required.
	Customer c1 =(Customer)context.getBean(Customer.class);
	Scanner s= new Scanner(System.in);
	System.out.println("Enter Customer Details: custid,custname");
		c1.setCid(s.nextInt());
		c1.setCname(s.next());
	System.out.println("Enter Address Details: stno,stname,stcity,stcolony");
	//Address a1 = context.getBean(Address.class);
	//Address a2 = context.getBean(Address.class);
		Address a1=c1.getCaddress();
		a1.setStno(s.nextInt());
		a1.setStname(s.next());
		a1.setCity(s.next());
		a1.setColony(s.next());
	  Address a2=c1.getCaddress();
        System.out.println(a1.hashCode());
        System.out.println(a2.hashCode());
  /*  System.out.println("Enter Order Details:orderid,ordername");
		Order o1 = c1.getCust_order1();
		o1.setOid(s.nextInt());
		o1.setOname(s.next());
    	*/   
	//c1.displayCustomerDetails();}
}
}//end of application
