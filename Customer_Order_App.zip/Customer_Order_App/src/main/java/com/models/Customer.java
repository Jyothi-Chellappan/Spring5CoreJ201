package com.models;

import org.springframework.beans.factory.annotation.Autowired;

public class Customer {
	int cid;
	String cname;
	Address caddress;
	Order cust_order1;

public int getCid() {
	return cid;
}
public void setCid(int cid) {
	this.cid = cid;
}
public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public Address getCaddress() {
	return caddress;
}

@Autowired
public void setCaddress(Address caddress) {
	this.caddress = caddress;
}

public Order getCust_order1() {
	return cust_order1;
}
public void setCust_order1(Order cust_order1) {
	this.cust_order1 = cust_order1;
}


@Override
public String toString() {
	return "Customer [cid=" + cid + ", cname=" + cname + ", caddress=" + caddress + ", cust_order1=" + cust_order1
			+ "]";
}
public void displayCustomerDetails() {
	
	System.out.println("------Customer Details:------");
	System.out.println("Cust ID:"+this.cid);
	System.out.println("Cust Name:"+this.cname);
	System.out.println("Street No:"+this.caddress.getStno());
	System.out.println("Street Name:"+this.caddress.getStname());
	System.out.println("City:"+this.caddress.getCity());
	System.out.println("Order Details:");
	System.out.println("Order ID:"+this.cust_order1.getOid());
	System.out.println("Order Name: "+this.cust_order1.getOname());
}

}
