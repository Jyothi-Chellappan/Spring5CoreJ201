package com.models;

import org.springframework.context.annotation.Scope;

@Scope(value="prototype")
public class Address {
 
 private int stno;
 private String stname;
 private String colony;
 private String city;
 private String district;
 private String state;
 
public int getStno() {
	return stno;
}
public void setStno(int stno) {
	this.stno = stno;
}
public String getStname() {
	return stname;
}
public void setStname(String stname) {
	this.stname = stname;
}
public String getColony() {
	return colony;
}
public void setColony(String colony) {
	this.colony = colony;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getDistrict() {
	return district;
}
public void setDistrict(String district) {
	this.district = district;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
 
 }
