package com.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.models.Address;
import com.models.Customer;
import com.models.Order;

@Configuration
public class Cust_Ord_Config {
  
	@Bean
	public Customer createCustomer(){
		return new Customer();
	}
	
	@Bean
	public Order createOder(){
		return new Order();
	}
	
	@Bean
	public Address createAddress(){
		return new Address();
	}
}
