package com.mainapplication;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.configuration.Cust_Prod_Config;
import com.models.Customer;
import com.models.Product;

public class Customer_Product_App {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(Cust_Prod_Config.class);
		Customer c1 =(Customer)context.getBean(Customer.class);
		System.out.println(c1);
		Product p1 = (Product)context.getBean(Product.class);
		System.out.println(p1);
	}
}
