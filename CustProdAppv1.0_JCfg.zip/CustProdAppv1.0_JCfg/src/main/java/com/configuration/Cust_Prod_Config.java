package com.configuration;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.models.Customer;
import com.models.Product;

@Configuration
public class Cust_Prod_Config {

	@Bean
	public Customer createCustomer(){
		
		return new Customer(100,"Customer1");
	}
	
	@Bean
		public Product createLaptop(){
		return new Product(2000,"Laptop");
	}
}
