package core.applications;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import core.beans.Employee;
public class EmployeeApplication {

	public static void main(String[] args) {
		//classpathxmlApplicationContext or FileSystemApplicationcontext
/*		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		Employee e1=(Employee)context.getBean("emp_one");
		System.out.println(e1.toString());
		*/
		
	}

}
//create a java project
//add springjar and commons-logging files to the build path
//create EmployeePojo and EmployeeApplication file
//Create a applicationContext.xml file(configure beans)
//execute the application.

//age
//total_no_of_days
//leaves
//basic(1000,2000)
//working_days and salary are local variables
/*calculateSalary(){

int working_days=total_no_ofdays-leaves
salary=basic*workingdays

}*/
/*
displaySalary(){
	return salary;
	
}*/