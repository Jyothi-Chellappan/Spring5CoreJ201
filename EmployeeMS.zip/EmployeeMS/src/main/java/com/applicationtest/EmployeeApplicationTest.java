package com.applicationtest;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.models.Employee;

public class EmployeeApplicationTest {
	public static void main(String[] args) {
		//classpathxmlApplicationContext or FileSystemApplicationcontext
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		Employee e1=(Employee)context.getBean("emp_one");
		System.out.println(e1.toString());
		
	}

}
