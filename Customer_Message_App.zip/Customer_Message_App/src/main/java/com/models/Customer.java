package com.models;

import org.springframework.beans.factory.annotation.Autowired;

import com.services.Inter_Message;

public class Customer {
	Inter_Message Im;

	public Inter_Message getIm() {
		return Im;
	}

	@Autowired
	public void setIm(Inter_Message im) {
		Im = im;
	}
}
