package com.mainapplication;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.config.Customer_Ser_Config;
import com.models.Customer;

/*Program to generate a Customer Order
 * Use @Scope,@Qualifier,@import,@PropertiesSource
 * JdbcTemplate @Predestroy
 */
public class Cust_Message {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(Customer_Ser_Config.class);
		Customer c1 =(Customer)context.getBean(Customer.class);
		System.out.println(c1);

	}

}
