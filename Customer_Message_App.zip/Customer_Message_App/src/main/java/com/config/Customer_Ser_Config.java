package com.config;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.models.Customer;

@Configuration
public class Customer_Ser_Config {

	@Bean
	public Customer createCustomer(){
			return new Customer();
	}
	
}
