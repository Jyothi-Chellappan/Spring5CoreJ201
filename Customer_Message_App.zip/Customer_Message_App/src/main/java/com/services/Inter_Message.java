package com.services;

public interface Inter_Message {

	public void sendMessage();
}
