package com.services;

public class SMS_Message implements Inter_Message{

	public void sendMessage() {
		System.out.println("Hude Discounts!!");
	}

}
