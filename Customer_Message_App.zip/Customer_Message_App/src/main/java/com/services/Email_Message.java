package com.services;

public class Email_Message implements Inter_Message{
	public void sendMessage() {
		System.out.println("Huge Discounts on Train Bookings!!!");
	}
}
