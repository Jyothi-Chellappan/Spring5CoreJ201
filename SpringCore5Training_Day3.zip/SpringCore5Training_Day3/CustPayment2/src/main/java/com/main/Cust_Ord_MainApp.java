package com.main;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.config.Cust_Order_Add_Config;
import com.models.Address;
import com.models.Customer;
import com.models.Email;


public class Cust_Ord_MainApp {

	public static void main(String[] args) {

		AnnotationConfigApplicationContext ac= new AnnotationConfigApplicationContext(Cust_Order_Add_Config.class);
		Customer c1=(Customer)ac.getBean(Customer.class);
		System.out.println(c1);
		                     Email e1=(Email)ac.getBean(Email.class);
		             		System.out.println(e1.hashCode());
		             		Email e2=(Email)ac.getBean(Email.class);
		             		System.out.println(e2.hashCode());
		             		Address a1 = ac.getBean(Address.class);
		             		System.out.println(a1);
		             		System.out.println(a1.hashCode());
		             		Address a2 = ac.getBean(Address.class);
		             		System.out.println(a2);         
		             		System.out.println(a2.hashCode());
	}

}
