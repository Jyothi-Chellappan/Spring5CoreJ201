package com.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.models.Customer;
import com.models.Email;

@Configuration
public class Email_config {

	@Bean
	@Scope("prototype")
	public Email createEmail(){
		return new Email();
	}
}
