package com.models;

import java.time.LocalDate;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;

public class Customer {

Address addr1;

public Customer() {
	
}

public void init() {
	System.out.println("inside init");
}

public void cleanUp() {
	System.out.println("Inside cleanup");
}
public Address getAddr1() {
	return addr1;
}

@Autowired
public void setAddr1(Address addr1) {
	this.addr1 = addr1;
}

@Override
public String toString() {
	return "Customer [addr1=" + addr1 + "]";
}



}
