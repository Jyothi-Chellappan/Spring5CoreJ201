package com.models;

public class Email {
 int id;
 String msg;

 public Email() {
	 
 }
 public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getMsg() {
	return msg;
}
public void setMsg(String msg) {
	this.msg = msg;
}
@Override
public String toString() {
	return "Email [id=" + id + ", msg=" + msg + "]";
}
  

}
