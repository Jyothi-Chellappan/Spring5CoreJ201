package com.models;

public class Address {
	int hno;
	String loc;
	
	public Address(int hno, String loc) {
		super();
		this.hno = hno;
		this.loc = loc;
	}

	public int getHno() {
		return hno;
	}

	public void setHno(int hno) {
		this.hno = hno;
	}

	public String getLoc() {
		return loc;
	}

	public void setLoc(String loc) {
		this.loc = loc;
	}

	@Override
	public String toString() {
		return "Address [hno=" + hno + ", loc=" + loc + "]";
	}
	
	
}
