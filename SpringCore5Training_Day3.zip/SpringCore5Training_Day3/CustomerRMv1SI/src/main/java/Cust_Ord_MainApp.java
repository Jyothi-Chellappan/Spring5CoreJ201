import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.config.Cust_Order_Add_Config;
import com.models.Customer;


public class Cust_Ord_MainApp {

	public static void main(String[] args) {

		AnnotationConfigApplicationContext ac= new AnnotationConfigApplicationContext(Cust_Order_Add_Config.class);
		Customer c1=(Customer)ac.getBean(Customer.class);
		System.out.println(c1);
	}

}
