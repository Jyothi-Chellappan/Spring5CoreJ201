package com.models;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

public class Order {

	int orderid;
	String ordername;
	//LocalTime order_time;
	Date order_date;
	float order_value;
	
	
	public Order(int orderid, String ordername,  Date order_date, float order_value) {
		super();
		this.orderid = orderid;
		this.ordername = ordername;
	//	this.order_time = order_time;
		this.order_date = order_date;
		this.order_value = order_value;
	}
	
	public int getOrderid() {
		return orderid;
	}
	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}
	public String getOrdername() {
		return ordername;
	}
	public void setOrdername(String ordername) {
		this.ordername = ordername;
	}
/*	public LocalTime getOrder_time() {
		return order_time;
	}
	public void setOrder_time(LocalTime order_time) {
		this.order_time = order_time;
	}*/
/*	public LocalDate getOrder_date() {
		return order_date;
	}
	public void setOrder_date(LocalDate order_date) {
		this.order_date = order_date;
	}*/
	public float getOrder_value() {
		return order_value;
	}
	public void setOrder_value(float order_value) {
		this.order_value = order_value;
	}

	}
