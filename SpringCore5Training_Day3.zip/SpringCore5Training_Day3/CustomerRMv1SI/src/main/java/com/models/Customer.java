package com.models;

import java.time.LocalDate;
import java.util.Date;

public class Customer {

int id;
String name;
Address addr1;
Address addr2;
float billamount;
String billtype;
Date bill_due_date;
Order o1;

public Customer(int id, String name, Address addr1, Address addr2, float billamount, String billtype,Date bill_due_date, Order o1) {
	super();
	this.id = id;
	this.name = name;
	this.addr1 = addr1;
	this.addr2 = addr2;
	this.billamount = billamount;
	this.billtype = billtype;
	this.bill_due_date = bill_due_date;
	this.o1 = o1;
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public Address getAddr1() {
	return addr1;
}

public void setAddr1(Address addr1) {
	this.addr1 = addr1;
}

public Address getAddr2() {
	return addr2;
}

public void setAddr2(Address addr2) {
	this.addr2 = addr2;
}

public float getBillamount() {
	return billamount;
}

public void setBillamount(float billamount) {
	this.billamount = billamount;
}

public String getBilltype() {
	return billtype;
}

public void setBilltype(String billtype) {
	this.billtype = billtype;
}

public Date getBill_due_date() {
	return bill_due_date;
}

public void setBill_due_date(Date bill_due_date) {
	this.bill_due_date = bill_due_date;
}

public Order getO1() {
	return o1;
}

public void setO1(Order o1) {
	this.o1 = o1;
}

}
