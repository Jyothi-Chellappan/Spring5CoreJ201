package com.config;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

import com.models.Address;
import com.models.Customer;
import com.models.Order;

public class Cust_Order_Add_Config {

	public Customer createCustomer(){
		Date ld = new Date();
		return new Customer(100,"Cust_one",createAddress(), createAddress(),167688.45f,"cash",ld,createOrder());
	}
	
	public Order createOrder() {
		Date d1 = new Date();
	//	LocalTime lt = new LocalTime(1,2,3);
		return new Order(1000,"IT_Support_Order",d1,89898.f);
	}
	
	public Address createAddress() {
		return new Address(1, "hyd");
	}
	
}
