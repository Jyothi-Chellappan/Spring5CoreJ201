package com.dao;

import java.util.List;

import com.model1.Customer;

public interface Cust_DAO_Inter {
		 
	    //userdefined methods to interact with database
		public void addCustomer(Customer customer);
	 
	    public void editCustomer(Customer customer, int customerId);
	 
	    public void deleteCustomer(int customerId);
	 
	    public Customer find(int customerId);
	 
	    public List < Customer > findAll();
	}