package com.dao;

	import java.util.List;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.beans.factory.annotation.Qualifier;
	import org.springframework.jdbc.core.BeanPropertyRowMapper;
	import org.springframework.jdbc.core.JdbcTemplate;
	import org.springframework.stereotype.Repository;

import com.model1.Customer;
	 
	@Repository
	@Qualifier("personDao")
	public class Cust_DAO_Impl implements Cust_DAO_Inter {
		 
	    @Autowired
	    JdbcTemplate jdbcTemplate;
	 
	    public void addCustomer(Customer Customer) {
	    	//jdbctemplate.update("query",getter method used to insert values);
	    	jdbcTemplate.update("INSERT INTO trn_Customer "
	    			+ "(Customer_id, first_name, Last_name, age) "
	    			+ "VALUES (?, ?, ?, ?)",
	       Customer.getCustomerId(), Customer.getFirstName(), Customer.getLastName(), Customer.getAge());
	        System.out.println("Customer Added!!");
	    }
	 
	    public void editCustomer(Customer Customer, int CustomerId) {
	        jdbcTemplate.update("UPDATE trn_Customer SET first_name = ? , last_name = ? , age = ? WHERE Customer_id = ? ",
	            Customer.getFirstName(), Customer.getLastName(), Customer.getAge(), CustomerId);
	        System.out.println("Customer Updated!!");
	    }
	 
	    public void deleteCustomer(int CustomerId) {
	        jdbcTemplate.update("DELETE from trn_Customer WHERE Customer_id = ? ", CustomerId);
	        System.out.println("Customer Deleted!!");
	    }
	 
	    public Customer find(int CustomerId) {
	        Customer Customer = (Customer) jdbcTemplate.queryForObject("SELECT * FROM trn_Customer where Customer_id = ? ",
	            new Object[] { CustomerId }, new BeanPropertyRowMapper(Customer.class));
	 
	        return Customer;
	    }
	 
	    public List < Customer > findAll() {
	        List < Customer > Customers = jdbcTemplate.query("SELECT * FROM trn_Customer", new BeanPropertyRowMapper(Customer.class));
	        return Customers;
	    }

		public void addCustomer1(Customer customer) {
			// TODO Auto-generated method stub
			
		}

		public void editCustomer1(Customer customer, int customerId) {
			
		}
		public Customer find1(int customerId) {
			return null;
		}
	}
