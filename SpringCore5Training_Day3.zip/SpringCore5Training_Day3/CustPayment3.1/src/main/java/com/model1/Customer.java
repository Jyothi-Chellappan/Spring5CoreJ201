package com.model1;

public class Customer {
	    
		private int customerId;
	    private String firstName;
	    private String lastName;
	    private int age;
   
	    
	    public Customer(int i, String string, String string2, int j) {
this.customerId=i;
//add additional methods
	    }
		public int getCustomerId() {
			return customerId;
		}
		public void setCustomerId(int customerId) {
			this.customerId = customerId;
		}
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		public int getAge() {
			return age;
		}
		public void setAge(int age) {
			this.age = age;
		}
}
