package com.service;

	import java.util.List;
	 
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;
	import com.dao.Cust_DAO_Impl;
	import com.model1.Customer;
	
	 
	@Service("customerService")
	public class Cust_ServiceImpl  implements Cust_Service {
	 
	    @Autowired
	    Cust_DAO_Impl customerDao;
	 
	    public void addCustomer(Customer cust) {
	    	customerDao.addCustomer(cust);
	 
	    }
	 
	    public void editCustomer(Customer cust, int custId) {
	    	customerDao.editCustomer(cust, custId);
	    }
	 
	    public void deleteCustomer(int custId) {
	    	customerDao.deleteCustomer(custId);
	    }
	 
	    public Customer find(int custId) {
	        return customerDao.find(custId);
	    }

		public List<Customer> findAll() {
			return null;
		}
    
	    
	}