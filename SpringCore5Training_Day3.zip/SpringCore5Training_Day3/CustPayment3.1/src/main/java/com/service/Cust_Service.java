package com.service;

import java.util.List;

import com.model1.Customer;
	 
	 public interface Cust_Service {
	 
	    public void addCustomer(Customer cust);
	 
	    public void editCustomer(Customer cust, int custId);
	 
	    public void deleteCustomer(int custId);
	 
	    public Customer find(int custId);
	 
	    public List < Customer > findAll();
	}

