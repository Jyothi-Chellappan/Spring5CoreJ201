package com.main;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import com.config.Cust_Order_Add_Config;
import com.model1.Customer;
import com.service.Cust_Service;
	 
	 
	public class Cust_db_Appn {
	 
	    public static void main(String args[]) {
	 
	        AbstractApplicationContext context = new AnnotationConfigApplicationContext(Cust_Order_Add_Config.class);
	        Cust_Service CustomerService = (Cust_Service) context.getBean("CustomerService");
	 
	        Customer yashwant = new Customer(1, "Yashwant", "Chavan", 32);
	        Customer mahesh = new Customer(2, "Mahesh", "Patil", 25);
	        Customer vishal = new Customer(3, "Vishal", "Naik", 40);
	 
	        CustomerService.addCustomer(yashwant);
	        CustomerService.addCustomer(mahesh);
	        CustomerService.addCustomer(vishal);
	 
	        System.out.println("Find All");
	        List < Customer > Customers = CustomerService.findAll();
	        for (Customer Customer: Customers) {
	            System.out.println(Customer);
	        }
	 
	        System.out.println("Delete Customer Id = 3");
	        int deleteMe = 3;
	        CustomerService.deleteCustomer(deleteMe);
	 
	        yashwant.setFirstName("Yashwant - Updated");
	        yashwant.setLastName("Chavan - Updated");
	        yashwant.setAge(40);
	 
	        System.out.println("Update Customer Id = 1");
	        int updateMe = 1;
	        CustomerService.editCustomer(yashwant, updateMe);
	 
	        System.out.println("Find Customer Id = 2");
	        Customer Customer = CustomerService.find(2);
	        System.out.println(Customer);
	 
	        System.out.println("Find All Again");
	        Customers = CustomerService.findAll();
	        for (Customer p: Customers) {
	            System.out.println(p);
	        }
	 
	        context.close();
	    }
	 
	}
