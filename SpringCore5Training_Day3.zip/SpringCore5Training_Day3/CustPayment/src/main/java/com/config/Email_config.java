package com.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.models.Customer;
import com.models.Email;

@Configuration
public class Email_config {

	@Bean
	public Email createEmail(){
		return new Email();
	}
}
