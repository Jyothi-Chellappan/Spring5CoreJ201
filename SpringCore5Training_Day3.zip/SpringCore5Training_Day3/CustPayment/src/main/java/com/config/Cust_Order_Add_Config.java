package com.config;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.models.Address;
import com.models.Customer;
import com.models.Order;

@Configuration
@Import(Email_config.class)
public class Cust_Order_Add_Config {

	@Bean
	public Customer createCustomer(){
		return new Customer();
	}
	@Bean
	public Address createAddress() {
	  return new Address(1, "hyd");
	}
	
}
