package com.main;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.config.Cust_Order_Add_Config;
import com.models.Customer;
import com.models.Email;


public class Cust_Ord_MainApp {

	public static void main(String[] args) {

		AnnotationConfigApplicationContext ac= new AnnotationConfigApplicationContext(Cust_Order_Add_Config.class);
		Customer c1=(Customer)ac.getBean(Customer.class);
		System.out.println(c1);
		                     Email e1=(Email)ac.getBean(Email.class);
		             		System.out.println(e1);

		                     
	}

}
